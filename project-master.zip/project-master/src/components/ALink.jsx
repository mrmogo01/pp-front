export default function ALink(props) {
    return (
        <a href="#a" className='ALink'>{props.Text}</a>
    )
}